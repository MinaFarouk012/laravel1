# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.64-MariaDB)
# Database: ecommerce
# Generation Time: 2020-09-06 12:08:51 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table customers
# ------------------------------------------------------------

DROP TABLE IF EXISTS `customers`;

CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customerName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerEmail` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerPhone` int(11) NOT NULL,
  `customerCity` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;

INSERT INTO `customers` (`id`, `customerName`, `customerEmail`, `customerPhone`, `customerCity`, `created_at`, `updated_at`)
VALUES
	(1,'mina ','mina@gmail.com',125489762,'cairo',NULL,NULL),
	(2,'mina 1','mina1@gmail.com',125489762,'ny',NULL,NULL),
	(3,'mina 2','min25a@gmail.com',125489762,'nc',NULL,NULL),
	(4,'mina 3','min88a@gmail.com',125489762,'ny',NULL,NULL),
	(5,'mina 4','m66ina@gmail.com',125489762,'nc',NULL,NULL),
	(6,'mina 5','66ina@gmail.com',125489762,'nc',NULL,NULL),
	(7,'mina 6','7ina@gmail.com',125489762,'nc',NULL,NULL),
	(8,'mina 7','7@gmail.com',125489762,'cairo',NULL,NULL),
	(9,'mina 8','8@gmail.com',125489762,'ny',NULL,NULL),
	(10,'mina 9','9@gmail.com',125489762,'ny',NULL,NULL),
	(11,'mina 10','10@gmail.com',125489762,'cairo',NULL,NULL),
	(12,'mina 11','n11@gmail.com',125489762,'cairo',NULL,NULL),
	(13,'mina 12','a12@gmail.com',125489762,'cairo',NULL,NULL),
	(14,'mina 13','m13@gmail.com',125489762,'cairo',NULL,NULL);

/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;

INSERT INTO `migrations` (`id`, `migration`, `batch`)
VALUES
	(1,'2020_09_06_033434_create_products_table',1),
	(2,'2020_09_06_033645_create_customers_table',1);

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table products
# ------------------------------------------------------------

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;

INSERT INTO `products` (`id`, `name`, `description`, `price`, `created_at`, `updated_at`)
VALUES
	(1,'Product 1 ','Product 1 Product 1 Product 1 Product 1 Product 1 Product 1 ',20.00,NULL,NULL),
	(2,'Product 2 ','Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',100.00,NULL,NULL),
	(3,'Product 3 ','Product 123 Product 1265 Product 1 Product 1 Product 1 Product 1 ',49.00,NULL,NULL),
	(4,'Product 4','4Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',63.00,NULL,NULL),
	(5,'Product 5 ','5Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',20.00,NULL,NULL),
	(6,'Product 6','6Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',95.00,NULL,NULL),
	(7,'Product 7 ','7Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',79.00,NULL,NULL),
	(8,'Product 8','8Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',58.00,NULL,NULL),
	(9,'Product 9 ','9Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',50.00,NULL,NULL),
	(10,'Product 10','10Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',30.00,NULL,NULL),
	(11,'Product 11 ','11Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',555.00,NULL,NULL),
	(12,'Product 12 ','12Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',80.00,NULL,NULL),
	(13,'Product 13 ','13Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',20.00,NULL,NULL),
	(14,'Product 14','14Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',20.00,NULL,NULL),
	(15,'Product 15 ','15Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',150.00,NULL,NULL),
	(16,'Product 16 ','16Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',160.00,NULL,NULL),
	(17,'Product 17 ','17Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',170.00,NULL,NULL),
	(18,'Product 18 ','18Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',30.00,NULL,NULL),
	(19,'Product 19 ','19Product 12 Product 1265 Product 1 Product 1 Product 1 Product 1 ',190.00,NULL,NULL);

/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
